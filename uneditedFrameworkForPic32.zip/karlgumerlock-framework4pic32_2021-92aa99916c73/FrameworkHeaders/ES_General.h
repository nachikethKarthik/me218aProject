#ifndef ES_General_H
#define ES_General_H

#define ARRAY_SIZE(x) (sizeof(x) / sizeof(x[0]))

#define BITS_PER_BYTE 8
#define BITS_PER_NYBBLE 4

#endif //ES_General_H
